<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class MY_Model extends CI_Model
{
    protected $_database_superadmin           = "wow_superadmin";
    protected $_table_project                 = "project";
    protected $_table_distributor             = "distributor";
}